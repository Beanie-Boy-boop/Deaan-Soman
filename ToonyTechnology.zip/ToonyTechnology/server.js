const express = require('express');
const mysql = require('mysql');
const bodyParser = require('body-parser');

const app = express();
const port = 3000;

// Middleware
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// MySQL Connection
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'your_password',
    database: 'contact_info_db'
});

db.connect((err) => {
    if (err) {
        throw err;
    }
    console.log('MySQL Connected...');
});

// Routes
app.post('/contact', (req, res) => {
    let contact = req.body;
    let sql = 'INSERT INTO contacts SET ?';
    db.query(sql, contact, (err, result) => {
        if (err) throw err;
        res.json({ message: 'Contact information saved successfully' });
    });
});

// Start Server
app.listen(port, () => {
    console.log(`Server started on port ${port}`);
});

// Middleware
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// MySQL Connection
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'your_password',
    database: 'ecommerce_db'
});

db.connect((err) => {
    if (err) {
        throw err;
    }
    console.log('MySQL Connected...');
});

// Routes
app.post('/checkout', (req, res) => {
    const { first_name, last_name, email, phone_number, payment_method } = req.body;
    const userQuery = 'INSERT INTO users (first_name, last_name, email, phone_number) VALUES (?, ?, ?, ?)';
    
    db.query(userQuery, [first_name, last_name, email, phone_number], (err, result) => {
        if (err) throw err;
        const userId = result.insertId;
        const orderQuery = 'INSERT INTO orders (user_id, total_amount) VALUES (?, ?)';
        const totalAmount = 1200.00; // You can calculate this dynamically based on the cart items

        db.query(orderQuery, [userId, totalAmount], (err, result) => {
            if (err) throw err;
            const orderId = result.insertId;
            const paymentQuery = 'INSERT INTO payments (order_id, payment_method, payment_status, amount) VALUES (?, ?, ?, ?)';
            const paymentStatus = 'Pending';

            db.query(paymentQuery, [orderId, payment_method, paymentStatus, totalAmount], (err, result) => {
                if (err) throw err;
                res.json({ message: 'Order placed successfully' });
            });
        });
    });
});

// Start Server
app.listen(port, () => {
    console.log(`Server started on port ${port}`);
});
